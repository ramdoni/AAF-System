<?php 
	/**
	 * KODAMI POCKET SYSTEM
	 */
?>
<footer class="footer text-center"> <?=date('Y')?> &copy; Arthaasia Finance System </footer>
