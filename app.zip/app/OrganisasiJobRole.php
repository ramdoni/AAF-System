<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OrganisasiJobRole extends Model
{
    protected $table = 'organisasi_job_role';
}
