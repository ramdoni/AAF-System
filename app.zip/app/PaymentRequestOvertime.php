<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PaymentRequestOvertime extends Model
{
    protected $table = 'payment_request_overtime';
}
