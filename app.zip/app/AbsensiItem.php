<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AbsensiItem extends Model
{
    protected $table = 'absensi_item';
}
