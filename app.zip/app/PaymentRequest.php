<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PaymentRequest extends Model
{
    protected $table = 'payment_request';

    /**
     * [user description]
     * @return [type] [description]
     */
    public function user()
    {
    	return $this->hasOne('App\User', 'id', 'user_id');
    }

    /**
     * [payment_request_form description]
     * @return [type] [description]
     */
    public function payment_request_form()
    {
    	return $this->hasMany('App\PaymentRequestForm', 'payment_request_id', 'id');
    }
}
