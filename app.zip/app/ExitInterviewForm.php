<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExitInterviewForm extends Model
{
    protected $table = 'exit_interview_form';
}
