<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExitClearanceInventoryGa extends Model
{
    protected $table = 'exit_clearance_inventory_ga';
}
