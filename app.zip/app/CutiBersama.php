<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CutiBersama extends Model
{
    protected $table = 'cuti_bersama';
}
