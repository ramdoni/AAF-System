<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InternalMemo extends Model
{
    protected $table = 'internal_memo';
}
