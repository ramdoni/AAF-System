<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RelatedSearchKaryawan extends Model
{
    protected $table = 'related_search_karyawan';
}
