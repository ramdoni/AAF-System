<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PaymentRequestBensin extends Model
{
    protected $table = 'payment_request_bensin';
}
