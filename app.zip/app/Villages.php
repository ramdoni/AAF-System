<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Villages extends Model
{
    protected $table = 'villages';
}
