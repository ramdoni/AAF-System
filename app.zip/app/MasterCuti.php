<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MasterCuti extends Model
{
    protected $table ='cuti';
}
