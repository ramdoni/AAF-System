<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OrganisasiDirectorate extends Model
{
    protected $table = 'organisasi_directorate';
}
