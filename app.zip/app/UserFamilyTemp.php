<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserFamilyTemp extends Model
{
    protected $table = 'user_family_temp';
}
