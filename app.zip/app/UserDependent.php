<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserDependent extends Model
{
    protected $table = 'user_dependent';
}
