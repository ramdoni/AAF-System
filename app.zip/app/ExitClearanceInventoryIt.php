<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExitClearanceInventoryIt extends Model
{
    protected $table = 'exit_clearance_inventory_it';
}
