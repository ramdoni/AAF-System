<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExitClearanceInventoryHrd extends Model
{
    protected $table = 'exit_clearance_inventory_hrd';
}
