<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExitClearance extends Model
{
    protected $table = 'exit_clearance';
}
