<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OrganisasiPosition extends Model
{
    protected $table = 'organisasi_position';
}
