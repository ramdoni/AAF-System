<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LiburNasional extends Model
{
    protected $table = 'libur_nasional';
}
