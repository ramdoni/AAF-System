<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExitClearanceDocument extends Model
{
    protected $table = 'exit_clearance_document';
}
