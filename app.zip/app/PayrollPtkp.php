<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PayrollPtkp extends Model
{
    protected $table = 'payroll_ptkp';
}
