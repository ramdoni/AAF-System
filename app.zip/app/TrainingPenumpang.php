<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TrainingPenumpang extends Model
{
    protected $table = 'training_penumpang';
}
