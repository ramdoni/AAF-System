<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserEducationTemp extends Model
{
    protected $table = 'user_education_temp';
}
