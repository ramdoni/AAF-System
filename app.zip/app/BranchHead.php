<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BranchHead extends Model
{
    protected $table = 'branch_head';
}
