<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TrainingBiayaLainnya extends Model
{
    protected $table = 'training_biaya_lainnya';
}
