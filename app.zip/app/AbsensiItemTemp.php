<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AbsensiItemTemp extends Model
{
    protected $table = 'absensi_item_temp';
}
