<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OvertimeSheetForm extends Model
{
    protected $table = 'overtime_sheet_form';
}
