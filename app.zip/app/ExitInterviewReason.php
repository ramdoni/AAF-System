<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExitInterviewReason extends Model
{
    protected $table = 'exit_interview_reason';
}
