<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PayrollOthers extends Model
{
    protected $table = 'payroll_others';
}
