<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PeraturanPerusahaan extends Model
{
    protected $table = 'peraturan_perusahaan';
}
